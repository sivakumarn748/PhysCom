from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, FileResponse, request
from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.db.models import Q
from datetime import datetime
from database.models import *
from feeds.models import *
from django.db.models import Count
import smtplib
from email.message import EmailMessage
import uuid
import humanize
import json

# Create your views here.

def login(request) :
    if request.method == 'POST' :
        userid = request.POST['userid']
        password = request.POST['password']
        try :
            # user = Person.objects.get(userid=userid)
            user = Person.objects.filter(userid__iexact=userid)
            if user :
                user = user[0]
                if password == user.password :
                    sessID = uuid.uuid4()
                    user.sessionID = sessID
                    user.lastseen=datetime.now()
                    user.save()
                    return JsonResponse({
                        'userid': user.userid,
                        'sessionID': sessID
                    })
                else :
                    return HttpResponse('<center><h1 style="font-family:monospace;color:red;">Invalid Password</h1></center>')

        except Person.DoesNotExist :
            return HttpResponse('<center><h1 style="font-family:monospace;color:red;">UserID doesnot exists</h1></center>')


def postcontent(request) :
    if request.method == 'GET' :
        postUUID = request.GET['uuid']
        post = Post.objects.get(post_id=postUUID)
        author = post.author

        likescount = post.likes.all().count()
        commentscount = post.comments.all().count()

        return JsonResponse({
            'userid': str(author.userid),
            'username': str(author.name),
            'naturaltime': str(humanize.naturaldate(post.postedAt)),
            'content_media_tag': f"<img src={str(post.mediaURL)} />" if post.media else "",
            'content_text': post.text.decode(),
            'likes_count': str(likescount),
            'comments_count': str(commentscount),
        })

def userprofile(request) :
    if request.method == 'GET' :
        userid = request.GET['userid']
        user = Person.objects.filter(userid__iexact=userid)
        if user :
            user = user[0]
            user.save()
            if user.profile :
                profile = user.profile.open('rb')
                return FileResponse(profile, as_attachment=False, filename='userprofile.jpg')
            else :
                return FileResponse(open('defaultprofile.png', 'rb'), as_attachment=False, filename='userprofile.jpg')
        else :
            return HttpResponse("User does not exists")

def hasUserID(request) :
    ID = request.GET['id']
    # if Person.objects.all().contains(Person(userid=ID)) :
    if Person.objects.filter(userid__iexact=ID) :
        return HttpResponse(1)
    else :
        return HttpResponse(0)

@csrf_exempt
def like(request) :
    if request.method == 'POST' :
        JSON = json.loads(request.body)
        sessID = JSON['sessID']
        postID = JSON['postID']

        try :
            person = Person.objects.get(sessionID=sessID)
            person.lastseen=datetime.now()
            person.save()

            try:
                post = Post.objects.get(post_id=postID)
                if post.likes.contains(person) :
                    post.likes.remove(person)
                    post.save()
                    c = post.likes.count()
                    return HttpResponse(f"{c},Unliked")
                else :
                    post.likes.add(person)
                    post.save()
                    c = post.likes.count()
                    return HttpResponse(f"{c},Liked")

            except Post.DoesNotExist :
                return HttpResponse("Post Does not Exist")

        except Person.DoesNotExist :
            return HttpResponse("Try Re-Login")

def userinfo(request, userid) :
    pass

def next10(request) :
    n = int(request.GET['n'])
    posts = Post.objects.annotate(likescount=Count('likes'))
    posts = posts.order_by('-postedAt', '-likescount')
    posts = posts[n:n+10]
    UUIDs = [str(post.post_id) for post in posts]
    return JsonResponse(UUIDs, safe=False)

def activities(request, userid, field) :
    try :
        n = int(request.GET['n'])
    except :
        n = 0
    user = Person.objects.filter(userid__iexact=userid)
    if user :
        A = user[0]
    else :
        return HttpResponse(f"User {userid} doesnot exists.")


    # Posts
    if field == 'posts' :
        posts = Post.objects.filter(author=A)
    # Replies
    if field == 'replies' :
        posts = Post.objects.filter(author=A, commented_to__isnull=False)
    # Media
    if field == 'media' :
        posts = Post.objects.filter(author=A).exclude(Q(media='')|Q(media=None))
    # Likes
    if field == 'likes' :
        posts = Person.objects.get(userid=userid).liked

    posts = posts.order_by('-postedAt')
    posts = posts[n:n+10]
    UUIDs = [str(post.post_id) for post in posts]
    return JsonResponse(UUIDs, safe=False)

def follow(request, userid, field) :
    try :
        n = int(request.GET['n'])
    except :
        n = 0
    user = Person.objects.get(userid=userid)
    # Following
    if field == 'following' :
        persons = user.following.all()
        persons = persons[n:n+15]
        IDs = [str(person.userid) for person in persons]
    # Follows
    if field == 'followers' :
        follow_object = Follow.objects.filter(follows=user)
        follow_object = follow_object[n:n+15]
        IDs = [str(person.user.userid) for person in follow_object]
        print(IDs)
    return JsonResponse(IDs, safe=False)

def about(request, userid)  :
    if request.method == "GET"  :
        user = Person.objects.filter(userid__iexact=userid)
        if user :
            user = user[0]
            try:
                sessID = request.GET['sessID']
                isfollowing = 1 if Person.objects.get(sessionID=sessID).following.contains(user) else 0
            except Exception as e:
                print(e)
                isfollowing = 0

            return JsonResponse({
                'userid': str(user.userid),
                'username': str(user.name),
                'about': str(user.about),
                'isfollowing': isfollowing
            })
        else :
            return HttpResponse("User Not found")

def editfollow(request, userid) :
    try:
        sessID = request.GET['sessID']
        visitor = Person.objects.get(sessionID=sessID)
    except :
        return HttpResponse("Try Re-login")
    try:
        user = Person.objects.get(userid=userid)
        user.lastseen=datetime.now()
        user.save()
        print(Follow.objects.filter(user=visitor, follows=user))
        if not Follow.objects.filter(user=visitor, follows=user) :
            Follow(user=visitor, follows=user).save()
            return HttpResponse("F")
        else :
            Follow.objects.filter(user=visitor, follows=user)[0].delete()
            return HttpResponse("UF")
    except Exception as e:
        print(e)
        return HttpResponse(0)

def isFollowing(request, userid) :
    sessID = request.GET['sessID']
    user = Person.objects.get(userid=userid)
    user.lastseen=datetime.now()
    user.save()
    visitor = Person.objects.filter(sessionID=sessID)
    if visitor :
        visitor = visitor[0]
        f = Follow.objects.filter(user=visitor, follows=user)
        if f :
            return HttpResponse(1)
        else :
            return HttpResponse(0)
    else :
        return HttpResponse(0)

@csrf_exempt
def isLiked(request) :
    if request.method=='POST' :
        d = json.loads(request.body)
        sessID = d['sessID']
        postID = d['postID']
        visitor = Person.objects.filter(sessionID=sessID)
        if visitor :
            visitor = visitor[0]
            post = Post.objects.get(post_id=postID)
            if Like.objects.filter(post=post, user=visitor) :
                return HttpResponse(1)
            else:
                return HttpResponse(0)

def email_alert(subject, body, to) :
	msg = EmailMessage()
	msg.set_content(body)
	msg['subject'] = subject
	msg['to'] = to

	user = "sivakumarn748@gmail.com"
	msg['from'] = user
	password = "xafe asdo ohdm ltvv"

	server = smtplib.SMTP("smtp.gmail.com", 587)
	server.starttls()
	server.login(user, password)
	server.send_message(msg)

	server.quit()

def sendVerificationKey(request) :
    mailid = request.GET['mailid']
    v = VerificationKey(mailid=mailid)
    v.save()
    body = str(v.key)
    email_alert('PhysCom Verification Key for Signup', body, mailid)
    return HttpResponse(1)
