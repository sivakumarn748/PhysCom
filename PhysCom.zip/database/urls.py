from django.urls import path
from . import views

app_name = 'api'

urlpatterns = [
    path('login/', view=views.login, name='login'),
    path('post-content/', view=views.postcontent, name='postcontent'),
    path('userprofile/', view=views.userprofile, name='userprofile'),
    path('hasUserID/', view=views.hasUserID, name='hasUserID'),
    path('like/', view=views.like, name='like'),
    path('userinfo/<str:userid>', view=views.userinfo, name='userinfo'),
    path('next10UUIDs/', view=views.next10, name='next10'),
    path('activities/<str:userid>/<str:field>/', view=views.activities, name='activities'),
    path('follow/<str:userid>/<str:field>/', view=views.follow, name='follow'),
    path('about/<str:userid>/', view=views.about, name='about'),
    path('editFollow/<str:userid>/', view=views.editfollow, name='editfollow'),
    path('isFollowing/<str:userid>/', view=views.isFollowing, name='isFollowing'),
    path('sendVerificationKey/', view=views.sendVerificationKey, name="sendVerificationKey"),
    path('isliked', view=views.isLiked, name='isliked')
    # path('verifyVerificationKey/', view=views.verifyVerificationKey, name="verifyVerificationKey"),
]
