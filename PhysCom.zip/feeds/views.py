from django.shortcuts import render
from django.http import HttpResponse, FileResponse, HttpResponseRedirect
from django.urls import reverse
from django.core.files.base import ContentFile
from django.db.models import Count
from database.models import Person
from feeds.models import Post
from datetime import datetime
import humanize
import uuid

# Create your views here.

def feed(request) :
    if request.method == 'GET' :
        posts = Post.objects.annotate(likescount=Count('likes'))
        posts = posts.order_by('-postedAt', '-likescount')
        if len(posts) > 15 :
            posts = posts[:15]
        UUIDs = [str(post.post_id) for post in posts]
        return render(request, 'feed.html', {
            'UUIDs' : UUIDs,
        })

def post(request, postid) :
    if request.method == 'GET' :
        post = Post.objects.get(post_id=postid)

        return render(request, 'post.html', {
            'author': post.author,
            'post': post,
            'naturaltime': str(humanize.naturaldate(post.postedAt)),
            'likescount': str(post.likes.all().count()),
            'commentscount': str(post.comments.all().count()),
            'comments': post.comments.all()
        })


def newPost(request) :
    if request.method == 'POST' :
        sessID = request.POST['sessID']
        text = request.POST['text']
        comment = False

        try :
            person = Person.objects.get(sessionID=sessID)
            person.lastseen=datetime.now()
            person.save()
            post = Post()
            post.text = text.encode(encoding='utf-8')
            post.author = person
            try :
                post.commented_to = Post.objects.get(post_id=request.POST['commented_to'])
                comment = True
            except :
                pass

            if request.FILES :
                file = request.FILES['media']
                post.media_name = file.name
                extension = file.name.split(".")[1]
                post.media.save(f"{uuid.uuid4()}.{extension}", ContentFile(file.read()))

            post.save()

        except Person.DoesNotExist :
            return HttpResponse("Try Re-login")

        if not comment :
            return HttpResponseRedirect(reverse('community:feed'))
        else :
            return HttpResponseRedirect(reverse('community:post', kwargs={'postid':request.POST['commented_to']}))

def media(request, filename) :
    if request.method == "GET" :
        try :
            return FileResponse(open(f"media/feeds/media/{filename}", "rb"), as_attachment=False, filename=filename)
        except :
            return HttpResponse(f"Cannot get file {filename}")

def activities(request, userid, field) :
    return render(request, 'activities_info.html', {
        'userid': userid,
        'field': field
    })

def follow(request, userid, field) :
    return render(request, 'follow_info.html', {
        'userid': userid,
        'field': field
    })
