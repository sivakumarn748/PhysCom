var users_pane = document.getElementById("users-pane");

var n = 0;

var renderedUsers = [];

function renderUser(userid) {
    
    var xhr = new XMLHttpRequest();
    var url = `/physcom/api/about/${userid}`;
    var params = "";
    if (localStorage.physcomsessID) {params += `&sessID=${localStorage.physcomsessID}`;}
    else {params+="&sessID=";}

    xhr.open('GET', `${url}?${params}`, true);

    xhr.onreadystatechange = function() {
        if (xhr.readyState==4 && xhr.status==200) {
            resp = JSON.parse(xhr.responseText);

            if (resp['isfollowing']=='1'){
                var follow_text = 'Following';
            }
            else {
                var follow_text = 'Follow';
            }
            var user_template = `
                <div>
                <a href="/physcom/app/user/${userid}"><label>
                    <div class="follow-profile">
                        <img src='/physcom/api/userprofile?userid=${resp['userid']}' />
                    </div>
                    <div class="follow-data">
                        <div class="follow-userdata">
                            <div class="follow-username">${resp['username']}</div>
                            <div class="follow-userid">@${resp['userid']}</div>
                            <label>${follow_text}</label>
                        </div>
                        <div class="follow-about">${resp['about']}</div>
                    </div>
                </label></a>
                </div>
                `;

            users_pane.innerHTML += user_template;
        }
    }

    xhr.send();
    
}

function loadNext15() {
    var xhr = new XMLHttpRequest();
    url = `/physcom/api/follow/${userid}/${field}?n=${n}`;
    xhr.open('GET', url, true);
    xhr.onreadystatechange = function(event) {
        json = JSON.parse(xhr.responseText);
        for(ID of json) {
            if (!renderedUsers.includes(ID)){
                renderUser(ID);
                renderedUsers.push(ID);
                n = n + 1;
            }
        }
    };
    xhr.send();
}

$(window).scroll(function() {
    if($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
        loadNext15();
    }
});

loadNext15();