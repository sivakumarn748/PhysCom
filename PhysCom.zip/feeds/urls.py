from django.urls import path
from . import views

app_name='community'

urlpatterns = [
    path('feeds/', view=views.feed, name='feed'),
    path('post/<str:postid>/', view=views.post, name='post'),
    path('new-post/', view=views.newPost, name='newpost'),
    path('media/<str:filename>', view=views.media, name='media'),
    path('activities/<str:userid>/<str:field>/', view=views.activities, name='activities'),
    path('follow/<str:userid>/<str:field>/', view=views.follow, name='follow'),
]
