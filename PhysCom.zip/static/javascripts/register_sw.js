function urlBase64ToUint8Array(base64String) {
  var padding = '='.repeat((4 - base64String.length % 4) % 4);
  var base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  var rawData = window.atob(base64);
  var outputArray = new Uint8Array(rawData.length);

  for (var i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

if ('serviceWorker' in navigator) {
   navigator.serviceWorker.register("/physcom/serviceworker.js", {
       'scope': '/physcom/'
   });
   setUpNotification();
}

async function subscribe() {
    var registration = await navigator.serviceWorker.getRegistration();
    var subscription = await registration.pushManager.subscribe({
       'userVisibleOnly': true,
       'applicationServerKey': urlBase64ToUint8Array('BDt6zCyx9atyjGWVHrdlQAvVByGIahKD6Z-oMTnpMy0IzMS_SgoTmOoFTEl0ZXn6-Cccz1uogxZuRrM5YSbm3f4')
    });
}

async function setUpNotification(){
    var permission = await Notification.requestPermission();
    if (permission === 'granted') {
        await subscribe();
    }
}


