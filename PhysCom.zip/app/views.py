from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, FileResponse
from django.urls import reverse
from django.db.models import Q
from database.models import Person
from datetime import datetime
from django.core.files.base import ContentFile
from database.models import *
from .forms import FormWithCaptcha
import uuid

# Create your views here.

def home(request) :
    pass

def signup(request) :
    if request.method == 'POST' :
        form = request.POST

        fc = FormWithCaptcha(form)
        if fc.is_valid():
            pass
        else :
            return HttpResponseRedirect(reverse('app:signup'))

        mailid = request.POST['email']
        key = request.POST['key']
        print(mailid, key)
        v = VerificationKey.objects.filter(mailid=mailid)
        print(str(v[0].key), key, str(v[0].key)==key)
        if (str(v[0].key)==key) :
            v[0].delete()
        else :
            return HttpResponseRedirect(reverse('app:signup'))

        # if Person.objects.all().contains(Person(userid=form['userid'])) :
        if Person.objects.filter(userid__iexact=form['userid']) :
            return HttpResponse(f"Userid {form['userid']} already exists. Try another userid.")

        person = Person(
            name=form['name'],
            userid=form['userid'],
            password=form['password'],
            email=form['email'],
            phone=form['phone'],
            about=form['bio'],
            dob=form['dob'],
        )
        person.save()
        if request.FILES :
            person.profile.save(form['userid']+'.jpg', ContentFile(request.FILES['profile'].read()))
            person.save()
        return HttpResponse("Created User @"+form['userid'])

    return render(request, 'signup.html', {
        'captcha': FormWithCaptcha()
    })

def login(request) :
    if request.method == 'GET' :
        try:
            next = request.GET['next']
        except :
            next = None
        return render(request, 'login.html', {
            'next': next,
            'captcha': FormWithCaptcha()
        })

    if request.method == 'POST' :
        fc = FormWithCaptcha(request.POST)
        if fc.is_valid():
            pass
        else :
            return HttpResponseRedirect(reverse('app:login'))
        userid = request.POST['userid']
        password = request.POST['password']
        try :
            user = Person.objects.filter(userid__iexact=userid)
            if not user :
                return HttpResponse('<center><h1 style="font-family:monospace;color:red;">UserID doesnot exists</h1></center>')
            else :
                user = user[0]
            if password == user.password :
                sessID = uuid.uuid4()
                user.sessionID = sessID
                user.lastseen=datetime.now()
                user.save()
                try:
                    next = request.POST['next']
                    return HttpResponse(f"<!DOCTYPE HTML><html><head><title>Success</title></head><body><script>localStorage.setItem('physcomsessID', '{sessID}');localStorage.setItem('userid', '{userid}');window.location.href='{next}';</script>Login successful</body></html>")
                except :
                    return HttpResponse(f"<!DOCTYPE HTML><html><head><title>Success</title></head><body><script>localStorage.setItem('physcomsessID', '{sessID}');localStorage.setItem('userid', '{userid}');window.location.href='/physcom/community/feeds';</script>Login successful</body></html>")
                # return HttpResponse(f"<!DOCTYPE HTML><html><head><title>Success</title></head><body><script>localStorage.setItem('physcomsessID', '{sessID}');localStorage.setItem('userid', '{userid}');window.location.href=;</script>Login successful</body></html>")
            else :
                return HttpResponse('<center><h1 style="font-family:monospace;color:red;">Invalid Password</h1></center>')

        except Person.DoesNotExist :
            return HttpResponse('<center><h1 style="font-family:monospace;color:red;">UserID doesnot exists</h1></center>')

def settings(request, sessID) :
    if request.method == "GET" :
        person = Person.objects.get(sessionID = sessID)
        return render(request, 'settings.html', {
            'person': person
        })

def bio(request, userid)  :
    if request.method == "GET"  :
        try :
            user = Person.objects.filter(userid__iexact=userid)
            if user :
                user = user[0]
                return render(request, "bio.html", {
                    'user': user,
                    'NoOfPost': user.post.count(),
                    'NoOfReplies': user.post.exclude(commented_to=None).count(),
                    'NoOfMedia': user.post.exclude(Q(media='')|Q(media=None)).count(),
                    'NoOfLikes': user.liked.count(),
                    'label': 'Follow',
                })
            else :
                return HttpResponse("User Not found")
        except Person.DoesNotExist :
            return HttpResponse("User Not found")

def activities(request, userid, field) :
    pass

def logout(request) :
    return HttpResponse(f"<!DOCTYPE HTML><html><head><title>Success</title></head><body><script>localStorage.removeItem('physcomsessID');localStorage.removeItem('userid');window.location.href='/physcom/community/feeds';</script>Logout successful</body></html>")

def sw(request) :
    return FileResponse(open("static/serviceworker.js", "rb"))