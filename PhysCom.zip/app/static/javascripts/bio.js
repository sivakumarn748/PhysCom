var followBtn = document.getElementById("followBtn");

followBtn.addEventListener('click', function(event) {
    sessionID=localStorage.getItem('physcomsessID');
    if (sessionID) {
        var xhr = new XMLHttpRequest();
        url = `/physcom/api/editFollow/${userid}/?sessID=${sessionID}`;
        xhr.open('GET', `${url}`, true);

        xhr.onreadystatechange = function() {
            if (xhr.readyState==4 && xhr.status==200) {
                resp = xhr.responseText;
                if (resp == 'F') 
                    followBtn.innerHTML = "Following";
                else if (resp == 'UF') 
                    followBtn.innerHTML = "Follow";
                else if (resp == 'Try Re-login') 
                    alert(resp);
            }
        }

        xhr.send();
    }
    else {
        res = confirm("Login to follow user");
        if (res) {
            location.href = `/physcom/app/login?next=${location.href}`;
        }
    }
});

function updateFollowButton(){
    sessionID=localStorage.getItem('physcomsessID');
    if (sessionID) {
        var xhr = new XMLHttpRequest();
        url = `/physcom/api/isFollowing/${userid}/?sessID=${sessionID}`;
        xhr.open('GET', `${url}`, true);

        xhr.onreadystatechange = function() {
            if (xhr.readyState==4 && xhr.status==200) {
                resp = xhr.responseText;
                if (resp == '1') {
                    followBtn.innerHTML = "Following";
                }
                else if (resp == '0') {
                    followBtn.innerHTML = "Follow";
                }
            }
        }

        xhr.send();
    }
}

updateFollowButton();