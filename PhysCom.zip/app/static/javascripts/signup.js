var userid_div = document.getElementById("userid");
var idexists = document.getElementById("idexists");
var verifyBtn = document.getElementById("verificationBtn");
idexists.style.color = 'red';

userid_div.addEventListener('input', function(){
    var value = userid_div.value;
    var xhr = new XMLHttpRequest();
    params = `id=${value}`;
    url = `/physcom/api/hasUserID?${params}`;
    xhr.open('GET', url, true);
    
    xhr.onreadystatechange = function() {
        if (xhr.readyState==4 && xhr.status==200) {
            var resp = xhr.responseText;
            if (resp=='1') {
                idexists.innerHTML = `UserID '${value}' already exists!`
            }
            else {
                idexists.innerHTML = '';
            }
        }
    }
    xhr.send();
});

verifyBtn.addEventListener('click', function(event){
    mailid = document.getElementById("email").value;
    var xhr = new XMLHttpRequest();
    url = "/physcom/api/sendVerificationKey/?mailid="+mailid;
    xhr.open('GET', url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState==4 && xhr.status==200) {
            if (xhr.responseText=='1')
                alert("Verification Key sent to your mail id : "+mailid);
        }
    }
    xhr.send();
});