# humanize

Welcome to the humanize API reference.

- [Number](number.md)
- [Time](time.md)
- [Filesize](filesize.md)
- [I18n](i18n.md)

{%
   include-markdown "../README.md"
   start="<!-- usage-start -->"
   end="<!-- usage-end -->"
   comments=false
%}
