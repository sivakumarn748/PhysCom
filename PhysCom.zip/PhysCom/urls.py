"""
URL configuration for PhysCom project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.http import FileResponse

def sw(request) :
    return FileResponse(open("static/serviceworker.js", "rb"))

def favicon(request) :
    return FileResponse(open("icon.png", "rb"))

urlpatterns = [
    path('physcom/admin/', admin.site.urls),
    path('physcom/', include('home.urls'), name='home'),
    path('physcom/api/', include('database.urls'), name='api'),
    path('physcom/community/', include('feeds.urls'), name='community'),
    path('physcom/rooms/', include('rooms.urls'), name='room'),
    path('physcom/schedules/', include('schedules.urls'), name='schedule'),
    path('physcom/app/', include('app.urls'), name='app'),
    path('physcom/serviceworker.js', view=sw, name='sw'),
    path('favicon.ico/', view=favicon, name='favicon')
]
